#include <iostream>
#include <conio.h>
using namespace std;
int vetor[7];

//RAFAEL FRANCISCO FERREIRA - 3� ANO C.C. UNESPAR
//HEAP MAXIMO

int Pai(int x){
	return(x/2);
}

void heap(int i, int qtde){
	int maior, e, d, aux;
	maior = i;
	if((2*i+1) <= qtde){
		e=(2*i+1);
		d=2*i;
		if(vetor[e] >= vetor[d] && vetor[e] > vetor[i]){
			maior = 2*i+1;
		}else if(vetor[d] > vetor[e] && vetor[d] > vetor[i]){
			maior = 2*i;
		}
	}else if((2*1) <= 6){
		d=2*i;
		if(vetor[d] < vetor[i]){
			maior = 2*i;
		}
	}
	if(maior!=i){
		aux = vetor[i];
		vetor[i] = vetor[maior];
		vetor[maior] = aux;
		heap(maior, qtde);
	}
}

int main(){
	int op,i,tamanho=0,maiorPrioridade,indice,numero;
	cout<<"HEAP MAXIMO - Rafael Francisco Ferreira\n\n";
	do{
		cout<<"\n1. Inserir";
		cout<<"\n2. Consultar";
		cout<<"\n3. Remover elemento de maior prioridade";
		cout<<"\n4. Sair ";
		cout<<"\nDigite a opcao desejada: ";
		
		cin>>op;
		
		switch(op){
			case 1:
				system("CLS");
				cout<<"\nInserindo na Heap\n";
				if(tamanho < 6){ //Se o tamanho for menor que o tamanho do vetor-1
					tamanho++; //incrementa o tamanho
					cout<<"\nDigite o valor a ser inserido: "; //solicita que o usu�rio digite um n�mero para inserir na heap
					cin>>numero;
					indice = tamanho; //o indice do vetor recebe o valor de tamanho
					
					while(indice > 1 && vetor[Pai(indice)] < numero){ //enquanto o indice for menor que 1 e o indice do elemento PAI do vetor for menor que o numero digitado				
						vetor[indice] = vetor[Pai(indice)]; //a posi��o atual recebe o valor da posi��o pai
						indice = Pai(indice); //indice recebe o valor da posi��o PAI
					} 
					vetor[indice] = numero; //a posi��o INDICE do vetor recebe o n�mero
					system("CLS");
					cout<<"\nElemento inserido com sucesso!\n";
				}else{
					cout<<"\nHEAP LOTADA!\n";
				}
				break;
			case 2:
				system("CLS");
				if(tamanho == 0){
					cout<<"\nHeap vazia\n";
				}else{
					cout<<"\nImprimindo os elementos da Heap: \n";
					for(i=0; i< tamanho+1; i++){
						cout<<"\nPosicao: "<<i<<" Elemento: "<<vetor[i];
					}
					cout<<"\n";
				}
				break;
			case 3:
				system("CLS");
				if(tamanho == 0){
					cout<<"\nHeap vazia\n";
				}else{
					maiorPrioridade = vetor[1];
					vetor[1] = vetor[tamanho];
					tamanho--;
					heap(1, tamanho);
					cout<<"\nO elemento removido foi: "<<maiorPrioridade<<"\n";
				}
				break;
			case 4:
				system("CLS");
				cout<<"Saindo...\n";
				break;
			default:
				cout<<"\nOpcao invalida!";
		}
	}while(op!=4);
}
