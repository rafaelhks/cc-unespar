#include <iostream>
using namespace std;
void fibonacci(int lim);

//RAFAEL FRANCISCO FERREIRA - 3� ANO CIENCIA DA COMPUTA��O - UNESPAR

int main(){
	int limite;
	cout << "Digite a quantidade de termos da sequ�ncia: ";
	cin >> limite;
	fibonacci(limite);
	return 0;
}

void fibonacci(int lim){
	int i, n;
	int S[lim] = {0,1};

	for(i=2; i<=lim+1;i++){
		n = S[i-1]+S[i-2];
		S[i] = n;
	}
	
	for(i=0;i<=lim;i++){
		cout<<S[i]<<", ";
	}
}

