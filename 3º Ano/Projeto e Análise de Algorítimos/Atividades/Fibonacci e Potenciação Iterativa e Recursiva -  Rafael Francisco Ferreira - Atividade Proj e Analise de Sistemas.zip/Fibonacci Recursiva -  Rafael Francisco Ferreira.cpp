#include <iostream>
#include <conio.h>
using namespace std;
int fibonacci(int lim);

//RAFAEL FRANCISCO FERREIRA - 3� ANO CIENCIA DA COMPUTA��O - UNESPAR

main()
{
   int limite, i;
   cout<<"Digite a quantidade de termos da sequencia: ";
   cin >> limite;
   cout<<"A sequencia de Fibonacci e: ";
   cout<<"0, ";
   for(i=0; i<limite; i++)
       cout<<fibonacci(i+1)<<", ";
   getch();
}

int fibonacci(int lim)
{
   if(lim==1 || lim==2)
       return 1;
   else
       return fibonacci(lim-1) + fibonacci(lim-2);
} 
