#include <iostream>
#include <conio.h>
using namespace std;
int potencia(int base, int expoente);

//RAFAEL FRANCISCO FERREIRA - 3� ANO CIENCIA DA COMPUTA��O - UNESPAR

int main(){
	int base, pot;
	cout<<"Digite o numero da base: ";
	cin>>base;
	cout<<"Digite o numero do expoente: ";
	cin>>pot;
	cout<<"O resultado de "<<base<<" elevado a "<<pot<<" eh: "<<potencia(base, pot);
	getch();
}

int potencia (int base, int expoente){
	int resultado = 1;
	for(int i=0; i<expoente; i++){
		resultado*=base;
	}
	return resultado;
}
