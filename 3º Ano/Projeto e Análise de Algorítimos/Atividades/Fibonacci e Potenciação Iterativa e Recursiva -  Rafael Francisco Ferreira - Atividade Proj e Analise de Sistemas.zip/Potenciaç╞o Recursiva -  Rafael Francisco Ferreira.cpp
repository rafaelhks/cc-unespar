#include <iostream>
#include <conio.h>
using namespace std;
int potencia(int base, int expoente);

//RAFAEL FRANCISCO FERREIRA - 3� ANO CIENCIA DA COMPUTA��O - UNESPAR

int main(){
	int base, pot;
	cout<<"Digite o numero da base: ";
	cin>>base;
	cout<<"Digite o numero do expoente: ";
	cin>>pot;
	cout<<"O resultado de "<<base<<" elevado a "<<pot<<" e: "<<potencia(base, pot);
	getch();
}

int potencia (int base, int expoente){
	if(expoente == 0)
		return 1;
	else
		return (base * potencia(base, expoente-1));
}
